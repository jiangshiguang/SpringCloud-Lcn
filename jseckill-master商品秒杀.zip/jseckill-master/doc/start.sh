nohup java -server -Xms256m -Xmx256m -Xmn64m -jar jseckill-backend.jar  >> /dev/null 2>&1 &

