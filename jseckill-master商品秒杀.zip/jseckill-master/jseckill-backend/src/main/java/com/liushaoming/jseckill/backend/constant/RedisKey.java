package com.liushaoming.jseckill.backend.constant;

public class RedisKey {
    public static final String SECKILL_ID_SET = "SECKILL_ID_SET";
    public static final String QUEUE_PRE_SECKILL = "QUEUE_PRE_SECKILL";
}
