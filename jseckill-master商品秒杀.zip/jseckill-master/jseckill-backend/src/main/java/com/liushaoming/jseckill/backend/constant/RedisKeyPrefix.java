package com.liushaoming.jseckill.backend.constant;

public class RedisKeyPrefix {
    public static final String SECKILL_GOODS = "SECKILL_GOODS:";
    public static final String SECKILL_INVENTORY = "SECKILL_INVENTORY:";
    public static final String BOUGHT_USERS = "BOUGHT_USERS:";
}
