package com.liushaoming.jseckill.backend.enums;

public enum AckAction {
    ACCEPT,
    RETRY,
    THROW
}
